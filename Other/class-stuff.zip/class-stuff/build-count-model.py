from composes.semantic_space.space import Space
from composes.utils import io_utils

#create a space from co-occurrence counts in sparse format
my_space = Space.build(data = "./text8.sm",
                       rows = "./text8.rows",
                       cols = "./text8.cols",
                       format = "sm")

#export the space in sparse format
#my_space.export("./text8", format = "sm")

#export the space in dense format
my_space.export("./text8", format = "dm")

io_utils.save(my_space, "./text8.pkl")

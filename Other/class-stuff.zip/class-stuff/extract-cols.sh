
cat "./text8.sm" | tr ' ' '\t' | cut -f 2 | sort | uniq | sort -R > "text8b.cols" 

from composes.utils import io_utils
from composes.similarity.cos import CosSimilarity

#load a space
predict = io_utils.load("./vectors.pkl")
count = io_utils.load("./text8.pkl")

#print my_space.cooccurrence_matrix
#print my_space.id2row

#compute similarity between two words in the space 
print count.get_sim("car", "car", CosSimilarity())
print predict.get_sim("car", "car", CosSimilarity())
print count.get_sim("car", "book", CosSimilarity())
print predict.get_sim("car", "book", CosSimilarity())

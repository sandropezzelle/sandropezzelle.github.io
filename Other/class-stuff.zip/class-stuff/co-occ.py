"""
@Aurelie Herbelot
modified by @Sandro Pezzelle
"""

#!/usr/bin/env python
#coding: utf-8


# This script takes a (not too large!) corpus and produces an sm file and a rows file to be fed into dissect.
# NB: dissect will also want a .cols file showing the dimensions of the space. This can be manually produced
# from the .rows file.

import pickle as pkl

cooccurrences = {}

#Hyperparameters
wsize = 2	#Window size 
fullwsize = 2 * wsize + 1
vocabsize = 1000	#Vocabulary size (n most frequent words in corpus)

#Corpus - change for your corpus. Assuming sentence split.
text8 = "./text8"


# Computing cooccurences and occurrences

print("Computing cooccurrences...")
with open(text8) as f:
    c = 0
    for s in f:
        tokens = s.rstrip('\n').lower().split()
        windows = [tokens[ind:ind+fullwsize] for ind,token in enumerate(tokens[:-wsize])]
        for window in windows:
            for ind,token in enumerate(window):
                if ind != wsize:
                    p = (window[wsize-1],token)
                    if p in cooccurrences:
                        cooccurrences[p]+=1
                    else:
                        cooccurrences[p]=1
        c+=1
        if c % 10000 == 0:
            print(str(c)+' sentences'+'...')
                    
occurrences = {}

print("Computing occurrences...")
for p,n in cooccurrences.items():
    for i in p:
        if i not in occurrences:
            occurrences[i] = n
        else:
            occurrences[i]+=n


print("Saving frequency pkl file...")
frequencies = [occurrences,cooccurrences]
#pkl.dump(frequencies, open( "text8-freq.pkl", "wb" ) )

#To re-open file in the future
#occurrences,cooccurrences = pkl.load( open ("text8-freq.pkl", "rb") )



#Get n most frequent words as dimensions (ignoring punctuation)

print("Computing vocabulary...")
from collections import Counter

punctuation = [c for c in '''!()-[]{};:'"\,<>./?@#$%^&*_~''']

d = Counter(occurrences)
vocab = [k for (k,v) in d.most_common(vocabsize) if k not in punctuation]


#Make vocab file

print("Making row file...")
out = open("text8-count.rows",'w')
for w in vocab:
    out.write(w+'\n')
out.close()


#Make sm file

print("Making sm file...")
out = open("text8-count.sm",'w')
for p,f in cooccurrences.items():
    if set(p) < set(vocab):
        out.write(p[0]+' '+p[1]+' '+str(f)+'\n')
out.close()
